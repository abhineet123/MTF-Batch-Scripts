#!/bin/bash -v
bashl nnkmn5k_ncc_50r_30i_50a_4u_no_ss_tulp.sh
bashl nnkmn5k_spss_50r_30i_50a_4u_no_ss_tulp.sh
bashl nnkmn5k_riu_50r_30i_50a_4u_no_ss_tulp.sh
