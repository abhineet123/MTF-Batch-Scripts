#!/bin/bash -v
bashl nnkmn6k_ssd_50r_30i_50a_4u_subseq10_tulp.sh
bashl nnkmn6k_riu_50r_30i_50a_4u_subseq10_tulp.sh
