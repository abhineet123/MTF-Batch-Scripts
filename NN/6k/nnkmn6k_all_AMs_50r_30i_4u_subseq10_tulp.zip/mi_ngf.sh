#!/bin/bash -v
bashl nnkmn2k_mi_24b_50r_30i_4u_subseq10_tulp.sh
bashl nnkmn2k_ngf_50r_30i_50a_4u_subseq10_tulp.sh
