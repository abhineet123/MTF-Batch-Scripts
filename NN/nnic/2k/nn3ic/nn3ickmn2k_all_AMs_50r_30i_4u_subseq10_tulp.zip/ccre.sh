#!/bin/bash -v
bashl nn3ickmn2k_ccre_24b_50r_30i_4u_subseq10_tulp.sh
