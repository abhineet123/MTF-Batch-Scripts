#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl fgnnkmn10k_ssim_50r_30i_50a_4u_subseq10_tmt_ucsb_lint_pami.sh
bashl fgnnkmn1k_ssim_50r_30i_50a_4u_subseq10_tmt_ucsb_lint_pami.sh
