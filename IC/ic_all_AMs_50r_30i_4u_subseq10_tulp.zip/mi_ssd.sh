#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl ic_ssd_50r_30i_4u_subseq10_tmt_ucsb_lint_pami.sh
bashl ic_mi10b_50r_30i_4u_subseq10_tmt_ucsb_lint_pami.sh
