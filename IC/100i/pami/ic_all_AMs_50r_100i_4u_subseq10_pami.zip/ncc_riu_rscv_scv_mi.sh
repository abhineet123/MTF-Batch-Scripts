#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl ic_scv_50r_100i_4u_subseq10_pami.sh
bashl ic_mi10b_50r_100i_4u_subseq10_pami.sh
bashl ic_ncc_50r_100i_4u_subseq10_pami.sh
bashl ic_riu_50r_100i_4u_subseq10_pami.sh
bashl ic_rscv_50r_100i_4u_subseq10_pami.sh
