#!/bin/bash -v
# NN with CCRE with 100r and SubSeq 10
bashl iclm_spss_25r_30i_4u_subseq10_tulp.sh
bashl iclm_riu_25r_30i_4u_subseq10_tulp.sh
bashl iclm_ngf_25r_30i_4u_subseq10_tulp.sh

bashl iclm_spss_100r_30i_4u_subseq10_tulp.sh
bashl iclm_riu_100r_30i_4u_subseq10_tulp.sh
bashl iclm_ngf_100r_30i_4u_subseq10_tulp.sh