#!/bin/bash -v
# NN with CCRE with 100r and SubSeq 10
bashl iclm_ssd_25r_30i_4u_subseq10_tulp.sh
bashl iclm_zncc_25r_30i_4u_subseq10_tulp.sh
bashl iclm_ssim_25r_30i_4u_subseq10_tulp.sh
bashl iclm_ncc_25r_30i_4u_subseq10_tulp.sh

bashl iclm_ssd_100r_30i_4u_subseq10_tulp.sh
bashl iclm_zncc_100r_30i_4u_subseq10_tulp.sh
bashl iclm_ssim_100r_30i_4u_subseq10_tulp.sh
bashl iclm_ncc_100r_30i_4u_subseq10_tulp.sh