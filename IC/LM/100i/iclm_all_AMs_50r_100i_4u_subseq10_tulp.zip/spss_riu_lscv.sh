#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl iclm_spss_50r_100i_4u_subseq10_tulp.sh
bashl iclm_riu_50r_100i_4u_subseq10_tulp.sh
bashl iclm_lscv_50r_100i_4u_subseq10_tulp.sh
