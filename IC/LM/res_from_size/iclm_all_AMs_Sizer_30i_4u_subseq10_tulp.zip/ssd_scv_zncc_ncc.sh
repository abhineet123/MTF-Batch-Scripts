#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl iclm_ssd_Sizer_30i_4u_subseq10_tulp.sh
bashl iclm_scv_Sizer_30i_4u_subseq10_tulp.sh
bashl iclm_zncc_Sizer_30i_4u_subseq10_tulp.sh
bashl iclm_ncc_Sizer_30i_4u_subseq10_tulp.sh
