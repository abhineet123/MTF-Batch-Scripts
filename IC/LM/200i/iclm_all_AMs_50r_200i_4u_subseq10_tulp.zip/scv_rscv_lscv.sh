#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl iclm_scv_50r_200i_4u_subseq10_tulp.sh
bashl iclm_rscv_50r_200i_4u_subseq10_tulp.sh
bashl iclm_lscv_50r_200i_4u_subseq10_tulp.sh
