#!/bin/bash -v
# NN with CCRE with 100r and SubSeq 10
bashl ic_ssd_25r_30i_4u_subseq10_tulp.sh
bashl ic_zncc_25r_30i_4u_subseq10_tulp.sh
bashl ic_ssim_25r_30i_4u_subseq10_tulp.sh
bashl ic_ncc_25r_30i_4u_subseq10_tulp.sh

bashl ic_ssd_100r_30i_4u_subseq10_tulp.sh
bashl ic_zncc_100r_30i_4u_subseq10_tulp.sh
bashl ic_ssim_100r_30i_4u_subseq10_tulp.sh
bashl ic_ncc_100r_30i_4u_subseq10_tulp.sh