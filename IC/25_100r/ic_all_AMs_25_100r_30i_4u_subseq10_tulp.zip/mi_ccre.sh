#!/bin/bash -v
# NN with CCRE with 100r and SubSeq 10
bashl ic_mi10b_25r_30i_4u_subseq10_tulp.sh
bashl ic_ccre10b_25r_30i_4u_subseq10_tulp.sh

bashl ic_mi10b_100r_30i_4u_subseq10_tulp.sh
bashl ic_ccre10b_100r_30i_4u_subseq10_tulp.sh