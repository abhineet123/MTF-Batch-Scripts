#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bash ./ic_ccre6b_50r_30i_4u_subseq10.sh
bash ./ic_ccre32b_50r_30i_4u_subseq10.sh
