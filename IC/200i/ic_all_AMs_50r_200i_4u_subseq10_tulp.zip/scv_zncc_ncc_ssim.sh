#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl ic_ncc_50r_200i_4u_subseq10_tulp.sh
bashl ic_scv_50r_200i_4u_subseq10_tulp.sh
bashl ic_ssim_50r_200i_4u_subseq10_tulp.sh
bashl ic_zncc_50r_200i_4u_subseq10_tulp.sh
