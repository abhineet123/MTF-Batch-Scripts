#!/bin/bash -v
bashl fc_ssd_50r_30i_4u_4_subseq10_tulp.sh
bashl fc_zncc_50r_30i_4u_4_subseq10_tulp.sh
bashl fc_mi8b_50r_30i_4u_4_subseq10_tulp.sh
