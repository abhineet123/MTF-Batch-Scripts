#!/bin/bash -v
bashl esmDJcw1_ssd_50r_30i_4u_4_subseq10_tulp.sh
bashl esmDJcw1_zncc_50r_30i_4u_4_subseq10_tulp.sh
