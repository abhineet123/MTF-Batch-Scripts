#!/bin/bash -v
bashl vpes_zncc_4_reinit_gt_subseq10_tulp.sh
bashl vpes_mi_4_reinit_gt_subseq10_tulp.sh
bashl vpes_ssd_4_reinit_gt_subseq10_tulp.sh
