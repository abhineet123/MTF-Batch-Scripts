#!/bin/bash -v
bashl vpfc_zncc_4_reinit_gt_subseq10_tulp.sh
bashl vpfc_mi_4_reinit_gt_subseq10_tulp.sh
bashl vpfc_ssd_4_reinit_gt_subseq10_tulp.sh
