#!/bin/bash -v
bashl vpfc_zncc_3_reinit_gt_subseq10_tulp.sh
bashl vpfc_mi_3_reinit_gt_subseq10_tulp.sh
bashl vpfc_ssd_3_reinit_gt_subseq10_tulp.sh
