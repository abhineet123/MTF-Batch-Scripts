#!/bin/bash -v
bashl vpes_zncc_3_reinit_gt_subseq10_tulp.sh
bashl vpes_mi_3_reinit_gt_subseq10_tulp.sh
bashl vpes_ssd_3_reinit_gt_subseq10_tulp.sh
