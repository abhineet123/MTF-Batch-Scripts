#!/bin/bash -v
bashl vpfa_zncc_3_reinit_gt_subseq10_tulp.sh
bashl vpfa_mi_3_reinit_gt_subseq10_tulp.sh
bashl vpfa_ssd_3_reinit_gt_subseq10_tulp.sh
