#!/bin/bash -v
bashl vpfa_zncc_subseq10_tulp.sh
bashl vpfa_mi_subseq10_tulp.sh
bashl vpfa_ssd_subseq10_tulp.sh
