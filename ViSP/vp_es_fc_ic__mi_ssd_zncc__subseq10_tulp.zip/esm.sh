#!/bin/bash -v
bashl vpes_zncc_subseq10_tulp.sh
bashl vpes_mi_subseq10_tulp.sh
bashl vpes_ssd_subseq10_tulp.sh
