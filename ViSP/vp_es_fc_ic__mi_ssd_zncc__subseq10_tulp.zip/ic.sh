#!/bin/bash -v
bashl vpic_zncc_subseq10_tulp.sh
bashl vpic_mi_subseq10_tulp.sh
bashl vpic_ssd_subseq10_tulp.sh
