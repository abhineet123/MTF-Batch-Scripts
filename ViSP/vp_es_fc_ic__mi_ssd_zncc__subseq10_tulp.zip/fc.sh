#!/bin/bash -v
bashl vpfc_zncc_subseq10_tulp.sh
bashl vpfc_mi_subseq10_tulp.sh
bashl vpfc_ssd_subseq10_tulp.sh
