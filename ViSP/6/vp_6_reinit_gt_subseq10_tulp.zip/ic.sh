#!/bin/bash -v
bashl vpic_zncc_6_reinit_gt_subseq10_tulp.sh
bashl vpic_mi_6_reinit_gt_subseq10_tulp.sh
bashl vpic_ssd_6_reinit_gt_subseq10_tulp.sh
