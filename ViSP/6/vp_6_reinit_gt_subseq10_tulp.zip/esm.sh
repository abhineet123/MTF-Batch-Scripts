#!/bin/bash -v
bashl vpes_zncc_6_reinit_gt_subseq10_tulp.sh
bashl vpes_mi_6_reinit_gt_subseq10_tulp.sh
bashl vpes_ssd_6_reinit_gt_subseq10_tulp.sh
