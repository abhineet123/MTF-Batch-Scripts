#!/bin/bash -v
bashl ic_ssd_50r_30i_4u_6_subseq10_tulp.sh
bashl ic_zncc_50r_30i_4u_6_subseq10_tulp.sh
bashl ic_mi8b_50r_30i_4u_6_subseq10_tulp.sh
