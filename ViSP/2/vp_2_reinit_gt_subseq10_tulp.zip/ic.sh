#!/bin/bash -v
bashl vpic_zncc_2_reinit_gt_subseq10_tulp.sh
bashl vpic_mi_2_reinit_gt_subseq10_tulp.sh
bashl vpic_ssd_2_reinit_gt_subseq10_tulp.sh
