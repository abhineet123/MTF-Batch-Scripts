#!/bin/bash -v
bashl vpfc_zncc_2_reinit_gt_subseq10_tulp.sh
bashl vpfc_mi_2_reinit_gt_subseq10_tulp.sh
bashl vpfc_ssd_2_reinit_gt_subseq10_tulp.sh
