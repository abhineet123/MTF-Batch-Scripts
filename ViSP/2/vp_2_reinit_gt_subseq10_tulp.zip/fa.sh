#!/bin/bash -v
bashl vpfa_zncc_2_reinit_gt_subseq10_tulp.sh
bashl vpfa_mi_2_reinit_gt_subseq10_tulp.sh
bashl vpfa_ssd_2_reinit_gt_subseq10_tulp.sh
