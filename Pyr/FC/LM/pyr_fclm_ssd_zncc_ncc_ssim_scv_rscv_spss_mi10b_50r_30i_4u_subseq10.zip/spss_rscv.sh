#!/bin/bash -v
bashl pyr_fclm_spss_50r_30i_4u_subseq10.sh
bashl pyr_fclm_rscv_50r_30i_4u_subseq10.sh
