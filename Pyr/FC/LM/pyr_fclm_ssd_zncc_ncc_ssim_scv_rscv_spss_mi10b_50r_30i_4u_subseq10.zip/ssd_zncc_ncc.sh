#!/bin/bash -v
bashl pyr_fclm_ssd_50r_30i_4u_subseq10.sh
bashl pyr_fclm_zncc_50r_30i_4u_subseq10.sh
bashl pyr_fclm_ncc_50r_30i_4u_subseq10.sh
