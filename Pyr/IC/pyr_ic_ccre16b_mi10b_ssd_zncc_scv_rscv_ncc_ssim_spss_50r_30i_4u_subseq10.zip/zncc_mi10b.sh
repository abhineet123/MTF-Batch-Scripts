#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bash ./pyr_ic_zncc_50r_30i_4u_subseq10.sh
bash ./pyr_ic_mi10b_50r_30i_4u_subseq10.sh
