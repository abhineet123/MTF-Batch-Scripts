#!/bin/bash -v
bashl pyr_iclm_zncc_50r_30i_4u_subseq10.sh
bashl pyr_iclm_ncc_50r_30i_4u_subseq10.sh
