#!/bin/bash -v
bashl pyr_iclm_ssd_100r_30i_4u_subseq10.sh
bashl pyr_iclm_riu_100r_30i_4u_subseq10_tulp.sh
