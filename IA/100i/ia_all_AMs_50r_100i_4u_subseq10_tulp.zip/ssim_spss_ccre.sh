#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl ia_spss_50r_100i_4u_subseq10_tmt_ucsb_lint_pami.sh
bashl ia_ssim_50r_100i_4u_subseq10_tmt_ucsb_lint_pami.sh
bashl ia_ccre16b_50r_100i_4u_subseq10_tmt_ucsb_lint_pami.sh