#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl ia_mi10b_50r_100i_4u_subseq10_tmt_ucsb_lint_pami.sh
bashl ia_riu_50r_100i_4u_subseq10_tmt_ucsb_lint_pami.sh
