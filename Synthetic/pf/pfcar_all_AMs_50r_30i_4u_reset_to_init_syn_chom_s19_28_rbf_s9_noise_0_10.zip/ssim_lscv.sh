#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl pfcar_ssim_50r_30i_4u_reset_to_init_syn_chom_s19_28_rbf_s9_noise_0_10.sh
bashl pfcar_lscv64b_50r_30i_4u_reset_to_init_syn_chom_s19_28_rbf_s9_noise_0_10.sh
