#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl synthetic_seq_generator_chom_s31_gb_s00_09_noiseless_pami_400_frames.sh
bashl synthetic_seq_generator_chom_s31_rbf_s00_09_noiseless_pami_400_frames.sh
