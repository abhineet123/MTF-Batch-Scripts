#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl iaC1_ssim_50r_30i_4u_2r_subseq10_tulp_reinit_gt.sh
bashl faC1_ssim_50r_30i_4u_2r_subseq10_tulp_reinit_gt.sh
