#!/bin/bash -v
bash ./frg_subseq10_tmtfineEIH_jaccard_mcd.sh
bash ./tld_subseq10_tmtfineEIH_jaccard_mcd.sh
