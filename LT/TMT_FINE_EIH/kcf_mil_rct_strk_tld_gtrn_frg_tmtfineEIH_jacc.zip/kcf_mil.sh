#!/bin/bash -v
bash ./kcf_subseq10_tmtfineEIH_jaccard_mcd.sh
bash ./mil_subseq10_tmtfineEIH_jaccard_mcd.sh
