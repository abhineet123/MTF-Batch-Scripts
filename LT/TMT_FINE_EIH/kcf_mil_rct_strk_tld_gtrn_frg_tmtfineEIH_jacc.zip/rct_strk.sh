#!/bin/bash -v
bash ./rct_subseq10_tmtfineEIH_jaccard_mcd.sh
bash ./strk_subseq10_tmtfineEIH_jaccard_mcd.sh
