#!/bin/bash -v
bash ./cmt2_subseq10_tmtfineEIH_jaccard_mcd.sh
bash ./cmt3_subseq10_tmtfineEIH_jaccard_mcd.sh
