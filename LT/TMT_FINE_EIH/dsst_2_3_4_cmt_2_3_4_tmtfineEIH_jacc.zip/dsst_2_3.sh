#!/bin/bash -v
bash ./dsst2_subseq10_tmtfineEIH_jaccard_mcd.sh
bash ./dsst3_subseq10_tmtfineEIH_jaccard_mcd.sh
