#!/bin/bash -v
bashl dsst4_subseq10_tmt_no_preproc.sh
bashl dsst2_subseq10_tmt_no_preproc.sh
bashl dsst3_subseq10_tmt_no_preproc.sh
