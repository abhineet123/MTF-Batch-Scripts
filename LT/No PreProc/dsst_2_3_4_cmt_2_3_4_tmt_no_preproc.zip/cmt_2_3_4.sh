#!/bin/bash -v
bashl cmt4_subseq10_tmt_no_preproc.sh
bashl cmt2_subseq10_tmt_no_preproc.sh
bashl cmt3_subseq10_tmt_no_preproc.sh
