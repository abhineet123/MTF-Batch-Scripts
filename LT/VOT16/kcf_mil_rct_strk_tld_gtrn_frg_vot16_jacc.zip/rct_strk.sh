#!/bin/bash -v
bash ./rct_subseq10_vot16_jaccard.sh
bash ./strk_subseq10_vot16_jaccard.sh
