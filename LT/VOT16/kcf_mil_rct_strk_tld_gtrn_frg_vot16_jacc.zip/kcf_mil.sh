#!/bin/bash -v
bash ./kcf_subseq10_vot16_jaccard.sh
bash ./mil_subseq10_vot16_jaccard.sh
