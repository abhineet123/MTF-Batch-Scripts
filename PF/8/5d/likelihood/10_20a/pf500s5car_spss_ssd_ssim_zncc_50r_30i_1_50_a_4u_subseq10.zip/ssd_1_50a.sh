#!/bin/bash -v
bashl pf500s5car_ssd_50r_30i_1a_4u_subseq10.sh
bashl pf500s5car_ssd_50r_30i_50a_4u_subseq10.sh
