#!/bin/bash -v
bashl pf500s1car_ncc_50r_30i_50a_4u_8_subseq10_tulp.sh
bashl pf500s1car_zncc_50r_30i_50a_4u_8_subseq10_tulp.sh
