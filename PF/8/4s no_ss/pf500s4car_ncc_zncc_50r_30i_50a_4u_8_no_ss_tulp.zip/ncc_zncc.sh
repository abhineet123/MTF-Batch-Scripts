#!/bin/bash -v
bashl pf500s4car_ncc_50r_30i_50a_4u_8_no_ss_tulp.sh
bashl pf500s4car_zncc_50r_30i_50a_4u_8_no_ss_tulp.sh
