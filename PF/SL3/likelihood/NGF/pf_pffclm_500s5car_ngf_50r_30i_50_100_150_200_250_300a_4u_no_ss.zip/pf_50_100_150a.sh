#!/bin/bash -v
bashl pf500s5car_ngf_50r_30i_50a_4u_no_ss.sh
bashl pf500s5car_ngf_50r_30i_100a_4u_no_ss.sh
bashl pf500s5car_ngf_50r_30i_150a_4u_no_ss.sh
