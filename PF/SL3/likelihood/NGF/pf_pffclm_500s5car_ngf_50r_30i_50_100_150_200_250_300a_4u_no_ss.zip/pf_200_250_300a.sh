#!/bin/bash -v
bashl pf500s5car_ngf_50r_30i_200a_4u_no_ss.sh
bashl pf500s5car_ngf_50r_30i_250a_4u_no_ss.sh
bashl pf500s5car_ngf_50r_30i_300a_4u_no_ss.sh
