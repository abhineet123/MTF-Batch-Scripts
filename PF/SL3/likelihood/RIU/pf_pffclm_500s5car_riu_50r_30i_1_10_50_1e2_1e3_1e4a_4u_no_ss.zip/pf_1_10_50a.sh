#!/bin/bash -v
bashl pf500s5car_riu_50r_30i_50a_4u_no_ss.sh
bashl pf500s5car_riu_50r_30i_1a_4u_no_ss.sh
bashl pf500s5car_riu_50r_30i_10a_4u_no_ss.sh
