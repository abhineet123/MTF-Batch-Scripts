#!/bin/bash -v
bashl pf500s5car_riu_50r_30i_100a_4u_no_ss.sh
bashl pf500s5car_riu_50r_30i_1000a_4u_no_ss.sh
bashl pf500s5car_riu_50r_30i_10000a_4u_no_ss.sh
