#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl fclm_mcncc_50r_30i_4u_subseq10_tulp.sh
bashl fclm_mcspss_50r_30i_4u_subseq10_tulp.sh
bashl fclm_mcssd_50r_30i_4u_subseq10_tulp.sh
bashl fclm_mcssim_50r_30i_4u_subseq10_tulp.sh
