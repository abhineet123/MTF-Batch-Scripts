#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl fclm_rscv_50r_10i_4u_subseq10_tulp.sh
bashl fclm_lscv_50r_10i_4u_subseq10_tulp.sh
bashl fclm_ngf_50r_10i_4u_subseq10_tulp.sh
