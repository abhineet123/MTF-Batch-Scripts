#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl fclm_spss_25r_30i_4u_subseq10_tulp.sh
bashl fclm_riu_25r_30i_4u_subseq10_tulp.sh
bashl fclm_ngf_25r_30i_4u_subseq10_tulp.sh
