#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl fclm_spss_50r_200i_4u_subseq10_tulp.sh
bashl fclm_riu_50r_200i_4u_subseq10_tulp.sh
bashl fclm_lscv_50r_200i_4u_subseq10_tulp.sh
