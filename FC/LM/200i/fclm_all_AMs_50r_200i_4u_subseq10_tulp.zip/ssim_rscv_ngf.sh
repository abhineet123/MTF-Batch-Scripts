#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl fclm_ssim_50r_200i_4u_subseq10_tulp.sh
bashl fclm_rscv_50r_200i_4u_subseq10_tulp.sh
bashl fclm_ngf_50r_200i_4u_subseq10_tulp.sh
