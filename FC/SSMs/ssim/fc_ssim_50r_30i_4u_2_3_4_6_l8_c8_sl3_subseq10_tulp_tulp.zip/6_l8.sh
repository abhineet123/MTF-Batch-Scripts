#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl fc_ssim_50r_30i_4u_6_subseq10_tulp.sh
bashl fc_ssim_50r_30i_4u_l8_subseq10_tulp.sh
