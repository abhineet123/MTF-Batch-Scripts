#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl fc_scv_50r_100i_4u_subseq10_pami.sh
bashl fc_mi10b_50r_100i_4u_subseq10_pami.sh
bashl fc_ncc_50r_100i_4u_subseq10_pami.sh
bashl fc_riu_50r_100i_4u_subseq10_pami.sh
bashl fc_rscv_50r_100i_4u_subseq10_pami.sh
