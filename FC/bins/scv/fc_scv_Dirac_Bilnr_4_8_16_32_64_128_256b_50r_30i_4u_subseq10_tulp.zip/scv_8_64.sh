#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bash ./fc_scvDirac8b_50r_30i_4u_subseq10.sh
bash ./fc_scvBilnr8b_50r_30i_4u_subseq10.sh
bash ./fc_scvDirac64b_50r_30i_4u_subseq10.sh
bash ./fc_scvBilnr64b_50r_30i_4u_subseq10.sh
