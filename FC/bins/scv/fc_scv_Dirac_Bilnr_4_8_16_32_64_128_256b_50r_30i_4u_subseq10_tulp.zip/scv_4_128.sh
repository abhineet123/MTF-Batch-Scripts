#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bash ./fc_scvDirac4b_50r_30i_4u_subseq10.sh
bash ./fc_scvBilnr4b_50r_30i_4u_subseq10.sh
bash ./fc_scvDirac128b_50r_30i_4u_subseq10.sh
bash ./fc_scvBilnr128b_50r_30i_4u_subseq10.sh
