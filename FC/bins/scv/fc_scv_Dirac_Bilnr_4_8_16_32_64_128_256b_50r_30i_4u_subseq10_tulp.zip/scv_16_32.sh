#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bash ./fc_scvDirac16b_50r_30i_4u_subseq10.sh
bash ./fc_scvBilnr16b_50r_30i_4u_subseq10.sh
bash ./fc_scvDirac32b_50r_30i_4u_subseq10.sh
bash ./fc_scvBilnr32b_50r_30i_4u_subseq10.sh
