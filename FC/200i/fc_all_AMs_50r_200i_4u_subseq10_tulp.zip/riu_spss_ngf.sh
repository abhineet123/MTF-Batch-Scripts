#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl fc_spss_50r_200i_4u_subseq10_tulp.sh
bashl fc_riu_50r_200i_4u_subseq10_tulp.sh
bashl fc_ngf_50r_200i_4u_subseq10_tulp.sh
