#!/bin/bash -v
# NN with CCRE with 100r and SubSeq 10
bashl esmDJcw1_riu_25r_30i_4u_subseq10_tulp.sh
bashl esmDJcw1_riu_100r_30i_4u_subseq10_tulp.sh
bashl esmDJcw1_spss_25r_30i_4u_subseq10_tulp.sh
bashl esmDJcw1_spss_100r_30i_4u_subseq10_tulp.sh
bashl esmDJcw1_ngf_25r_30i_4u_subseq10_tulp.sh
bashl esmDJcw1_ngf_100r_30i_4u_subseq10_tulp.sh
