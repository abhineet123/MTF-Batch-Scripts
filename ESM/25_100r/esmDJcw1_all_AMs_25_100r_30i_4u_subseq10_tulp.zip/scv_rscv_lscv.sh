#!/bin/bash -v
# NN with CCRE with 100r and SubSeq 10
bashl esmDJcw1_rscv_25r_30i_4u_subseq10_tulp.sh
bashl esmDJcw1_rscv_100r_30i_4u_subseq10_tulp.sh
bashl esmDJcw1_scv_25r_30i_4u_subseq10_tulp.sh
bashl esmDJcw1_scv_100r_30i_4u_subseq10_tulp.sh
bashl esmDJcw1_lscv_25r_30i_4u_subseq10_tulp.sh
bashl esmDJcw1_lscv_100r_30i_4u_subseq10_tulp.sh
