#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl esmDJcw1_ssim_50r_30i_4u_6_subseq10_tulp.sh
bashl esmDJcw1_ssim_50r_30i_4u_l8_subseq10_tulp.sh
