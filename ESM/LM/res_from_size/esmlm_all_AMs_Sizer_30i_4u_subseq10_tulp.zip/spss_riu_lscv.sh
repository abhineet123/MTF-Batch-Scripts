#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl esmlm_spss_Sizer_30i_4u_subseq10_tulp.sh
bashl esmlm_riu_Sizer_30i_4u_subseq10_tulp.sh
bashl esmlm_lscv_Sizer_30i_4u_subseq10_tulp.sh
