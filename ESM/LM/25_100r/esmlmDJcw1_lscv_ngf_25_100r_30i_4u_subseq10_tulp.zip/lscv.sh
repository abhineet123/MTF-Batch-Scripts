#!/bin/bash -v
bashl esmlmDJcw1_lscv_25r_30i_4u_subseq10_tulp.sh
bashl esmlmDJcw1_lscv_100r_30i_4u_subseq10_tulp.sh

