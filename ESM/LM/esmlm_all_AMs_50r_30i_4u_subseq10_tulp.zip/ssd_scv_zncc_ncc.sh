#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl esmlm_ssd_50r_30i_4u_subseq10_tulp.sh
bashl esmlm_scv_50r_30i_4u_subseq10_tulp.sh
bashl esmlm_zncc_50r_30i_4u_subseq10_tulp.sh
bashl esmlm_ncc_50r_30i_4u_subseq10_tulp.sh
