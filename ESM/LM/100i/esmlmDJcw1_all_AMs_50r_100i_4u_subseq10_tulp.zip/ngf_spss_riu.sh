#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl esmlmDJcw1_riu_50r_100i_4u_subseq10_tulp.sh
bashl esmlmDJcw1_spss_50r_100i_4u_subseq10_tulp.sh
bashl esmlmDJcw1_ngf_50r_100i_4u_subseq10_tulp.sh
