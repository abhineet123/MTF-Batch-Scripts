#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl esmlmDJcw1_ncc_50r_100i_4u_subseq10_tulp.sh
bashl esmlmDJcw1_scv_50r_100i_4u_subseq10_tulp.sh
bashl esmlmDJcw1_ssim_50r_100i_4u_subseq10_tulp.sh
bashl esmlmDJcw1_zncc_50r_100i_4u_subseq10_tulp.sh
