#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl esmDJcw1_riu_50r_200i_4u_subseq10_tulp.sh
bashl esmDJcw1_spss_50r_200i_4u_subseq10_tulp.sh
bashl esmDJcw1_ngf_50r_200i_4u_subseq10_tulp.sh
