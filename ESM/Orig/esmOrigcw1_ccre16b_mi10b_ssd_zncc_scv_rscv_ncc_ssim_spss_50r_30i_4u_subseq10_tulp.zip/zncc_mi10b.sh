#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bash ./esmOrigcw1_zncc_50r_30i_4u_subseq10.sh
bash ./esmOrigcw1_mi10b_50r_30i_4u_subseq10.sh
