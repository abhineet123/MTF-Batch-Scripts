#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl esmDJcw1_zncc_50r_30i_4u_subseq10_pami.sh
bashl esmDJcw1_mi10b_50r_30i_4u_subseq10_pami.sh
