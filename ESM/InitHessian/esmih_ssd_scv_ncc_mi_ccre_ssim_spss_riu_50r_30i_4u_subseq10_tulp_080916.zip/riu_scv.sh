#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bash ./esmihDJcw1_riu_50r_30i_4u_subseq10.sh
bash ./esmihDJcw1_scv_50r_30i_4u_subseq10.sh
