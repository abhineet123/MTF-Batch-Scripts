#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl gridfclm5rLMS50p10Ki5t_riu_50r_30i_4u_subseq10.sh
bashl gridfclm5rLMS50p10Ki5t_ssd_50r_30i_4u_subseq10.sh
bashl rklfclm5rLMS50p10Ki5t_riu_50r_30i_4u_subseq10_tulp.sh
bashl rklfclm5rLMS50p10Ki5t_ssd_50r_30i_4u_subseq10_tulp.sh
