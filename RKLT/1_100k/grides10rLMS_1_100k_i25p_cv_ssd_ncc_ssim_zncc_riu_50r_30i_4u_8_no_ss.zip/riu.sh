#!/bin/bash -v
bashl grides10rLMS25p100Ki5t_riu_50r_30i_4u_no_ss.sh
bashl grides10rLMS25p1Ki5t_riu_50r_30i_4u_no_ss.sh
