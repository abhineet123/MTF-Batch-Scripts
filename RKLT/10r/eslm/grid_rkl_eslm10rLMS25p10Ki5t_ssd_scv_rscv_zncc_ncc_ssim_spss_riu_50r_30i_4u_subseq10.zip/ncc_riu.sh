#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl grideslm10rLMS25p10Ki5t_ncc_50r_30i_4u_subseq10.sh
bashl grideslm10rLMS25p10Ki5t_riu_50r_30i_4u_subseq10.sh
bashl rkleslm10rLMS25p10Ki5t_ncc_50r_30i_4u_subseq10.sh
bashl rkleslm10rLMS25p10Ki5t_riu_50r_30i_4u_subseq10.sh
