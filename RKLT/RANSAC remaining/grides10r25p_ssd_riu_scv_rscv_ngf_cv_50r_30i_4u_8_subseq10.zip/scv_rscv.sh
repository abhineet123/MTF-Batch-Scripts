#!/bin/bash -v
bashl grides10r25p10Ki5t_scv64b_50r_30i_4u_subseq10.sh
bashl grides10r25p10Ki5t_rscv64b_50r_30i_4u_subseq10.sh
