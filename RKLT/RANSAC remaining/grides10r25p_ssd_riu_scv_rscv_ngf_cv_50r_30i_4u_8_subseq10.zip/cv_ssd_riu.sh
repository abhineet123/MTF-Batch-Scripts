#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl grides10r25p10Ki5t_ssd_50r_30i_4u_subseq10.sh
bashl grides10r25p10Ki5t_riu_50r_30i_4u_subseq10.sh
bashl gridcv10r25p_ssd_50r_30i_4u_8_subseq10.sh
