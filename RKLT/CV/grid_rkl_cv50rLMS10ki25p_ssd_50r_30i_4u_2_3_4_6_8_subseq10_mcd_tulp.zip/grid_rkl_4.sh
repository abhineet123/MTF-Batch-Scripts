#!/bin/bash -v

bashl gridcv50rLMS10ki25p_ncc_50r_30i_4u_4_subseq10_mcd.sh
bashl rklcv50rLMS10ki25pfc_ncc_50r_30i_4u_4_subseq10_mcd.sh
