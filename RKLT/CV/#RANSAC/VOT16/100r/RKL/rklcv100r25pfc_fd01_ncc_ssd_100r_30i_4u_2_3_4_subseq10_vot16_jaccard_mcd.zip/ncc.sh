#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl rklcv100r25pfc_ncc_50r_30i_4u_4_subseq10_vot16_jaccard_mcd.sh
bashl rklcv100r25pfc_ncc_50r_30i_4u_2_subseq10_vot16_jaccard_mcd.sh
bashl rklcv100r25pfc_ncc_50r_30i_4u_3_subseq10_vot16_jaccard_mcd.sh
