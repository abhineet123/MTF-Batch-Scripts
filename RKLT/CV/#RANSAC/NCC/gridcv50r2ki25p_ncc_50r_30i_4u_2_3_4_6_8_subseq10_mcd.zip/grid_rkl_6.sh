#!/bin/bash -v

bashl gridcv50r2ki25p_ncc_50r_30i_4u_6_subseq10_mcd.sh
bashl rklcv50r2ki25pfc_ncc_50r_30i_4u_6_subseq10_mcd.sh
