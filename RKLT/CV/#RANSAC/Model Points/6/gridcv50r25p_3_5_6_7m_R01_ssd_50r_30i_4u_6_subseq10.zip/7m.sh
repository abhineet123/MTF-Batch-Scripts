#!/bin/bash -v
bash ./gridcv50r25p7mR0_ssd_50r_30i_4u_6_subseq10.sh
bash ./gridcv50r25p7m_ssd_50r_30i_4u_6_subseq10.sh

