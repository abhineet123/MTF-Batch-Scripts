#!/bin/bash -v
bash ./gridcv50r25p3mR0_ssd_50r_30i_4u_4_subseq10.sh
bash ./gridcv50r25p3m_ssd_50r_30i_4u_4_subseq10.sh

