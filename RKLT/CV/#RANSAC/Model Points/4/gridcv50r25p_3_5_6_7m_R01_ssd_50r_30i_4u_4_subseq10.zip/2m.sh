#!/bin/bash -v
bash ./gridcv50r25p2mR0_ssd_50r_30i_4u_4_subseq10.sh
bash ./gridcv50r25p2m_ssd_50r_30i_4u_4_subseq10.sh

