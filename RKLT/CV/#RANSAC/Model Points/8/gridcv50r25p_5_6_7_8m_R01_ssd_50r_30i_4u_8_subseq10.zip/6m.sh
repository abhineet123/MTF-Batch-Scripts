#!/bin/bash -v
bash ./gridcv50r25p6mR0_ssd_50r_30i_4u_8_subseq10.sh
bash ./gridcv50r25p6m_ssd_50r_30i_4u_8_subseq10.sh

