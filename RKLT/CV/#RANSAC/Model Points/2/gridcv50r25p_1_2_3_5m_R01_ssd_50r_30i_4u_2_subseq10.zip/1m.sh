#!/bin/bash -v
bash ./gridcv50r25p1mR0_ssd_50r_30i_4u_2_subseq10.sh
bash ./gridcv50r25p1m_ssd_50r_30i_4u_2_subseq10.sh

