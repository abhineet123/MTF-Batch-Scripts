#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl rklcvfd100r25pfc_ssd_100r_30i_4u_8_subseq10_tmtfineEIH_jaccard_mcd.sh
bashl rklcvfd100r25pfc_ssd_100r_30i_4u_6_subseq10_tmtfineEIH_jaccard_mcd.sh
