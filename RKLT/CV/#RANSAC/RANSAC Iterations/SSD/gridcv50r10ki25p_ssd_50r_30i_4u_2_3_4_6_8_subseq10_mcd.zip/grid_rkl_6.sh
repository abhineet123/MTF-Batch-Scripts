#!/bin/bash -v

bashl gridcv50r10ki25p_ssd_50r_30i_4u_6_subseq10_mcd.sh
bashl rklcv50r10ki25pfc_ssd_50r_30i_4u_6_subseq10_mcd.sh
