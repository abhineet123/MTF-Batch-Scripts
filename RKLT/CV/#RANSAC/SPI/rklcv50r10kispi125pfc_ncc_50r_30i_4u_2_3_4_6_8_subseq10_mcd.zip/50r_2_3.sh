#!/bin/bash -v

bashl rklcv50r10kispi125pfc_ncc_50r_30i_4u_2_subseq10_mcd.sh
bashl rklcv50r10kispi125pfc_ncc_50r_30i_4u_3_subseq10_mcd.sh
