#!/bin/bash -v

bashl gridcv5rLMS10ki25p_ssd_50r_30i_4u_8_subseq10_tulp.sh
bashl gridcv10rLMS10ki25p_ssd_50r_30i_4u_8_subseq10_tulp.sh
