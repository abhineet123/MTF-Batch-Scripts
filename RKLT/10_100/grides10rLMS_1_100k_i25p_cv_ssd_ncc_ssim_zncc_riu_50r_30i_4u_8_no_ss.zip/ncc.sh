#!/bin/bash -v
bashl grides10rLMS25p100i5t_ncc_50r_30i_4u_no_ss.sh
bashl grides10rLMS25p10i5t_ncc_50r_30i_4u_no_ss.sh
 