#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl fa_ssim_50r_100i_4u_iiw0_subseq10_tulp.sh
bashl fa_spss_50r_100i_4u_iiw0_subseq10_tulp.sh
bashl fa_riu_50r_100i_4u_iiw0_iiw0_subseq10_tulp.sh