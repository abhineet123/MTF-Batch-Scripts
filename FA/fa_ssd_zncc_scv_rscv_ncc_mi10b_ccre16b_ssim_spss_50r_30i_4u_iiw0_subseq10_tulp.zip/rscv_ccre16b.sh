#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bash ./fa_rscv_50r_30i_4u_subseq10.sh
bash ./fa_ccre16b_50r_30i_4u_subseq10.sh
