#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl falm_ccre16b_50r_30i_4u_iiw0_subseq10_tulp.sh

