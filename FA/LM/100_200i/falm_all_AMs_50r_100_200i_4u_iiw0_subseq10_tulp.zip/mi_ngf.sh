#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl falm_ngf_50r_200i_4u_iiw0_subseq10_tulp.sh
bashl falm_ngf_50r_100i_4u_iiw0_subseq10_tulp.sh
bashl falm_mi10b_50r_200i_4u_iiw0_subseq10_tulp.sh
bashl falm_mi10b_50r_100i_4u_iiw0_subseq10_tulp.sh
