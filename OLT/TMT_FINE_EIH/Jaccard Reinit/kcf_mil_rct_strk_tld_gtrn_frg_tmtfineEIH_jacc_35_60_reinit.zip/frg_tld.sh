#!/bin/bash -v
bashl frg_subseq10_tmtfineEIH_jaccard_35_60_reinit.sh
bashl tld_subseq10_tmtfineEIH_jaccard_35_60_reinit.sh
