#!/bin/bash -v
bashl rct_subseq10_tmtfineEIH_jaccard_35_60_reinit.sh
bashl strk_subseq10_tmtfineEIH_jaccard_35_60_reinit.sh
