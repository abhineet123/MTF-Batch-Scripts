#!/bin/bash -v
bashl kcf_subseq10_tmtfineEIH_jaccard_35_60_reinit.sh
bashl mil_subseq10_tmtfineEIH_jaccard_35_60_reinit.sh
