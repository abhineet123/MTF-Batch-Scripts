#!/bin/bash -v
bashl cmt2_subseq10_tmtfineEIH_jaccard_35_60_reinit.sh
bashl cmt3_subseq10_tmtfineEIH_jaccard_35_60_reinit.sh
