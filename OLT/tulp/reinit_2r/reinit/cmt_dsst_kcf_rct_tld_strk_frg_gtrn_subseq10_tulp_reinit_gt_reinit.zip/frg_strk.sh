#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl frg_subseq10_tulp_reinit_gt_reinit.sh
bashl strk_subseq10_tulp_reinit_gt_reinit.sh
