#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl dsst2_subseq10_tulp_reinit_gt_reinit.sh
bashl cmt2_subseq10_tulp_reinit_gt_reinit.sh
