#!/bin/bash -v
# NN with CCRE with 50r and SubSeq 10
bashl gtrn_subseq10_tulp_reinit_gt_reinit.sh
bashl tld_subseq10_tulp_reinit_gt_reinit.sh
