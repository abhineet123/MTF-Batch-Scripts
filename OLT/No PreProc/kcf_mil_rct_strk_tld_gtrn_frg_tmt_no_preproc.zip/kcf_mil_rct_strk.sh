#!/bin/bash -v
bashl strk_subseq10_tmt_no_preproc.sh
bashl kcf_subseq10_tmt_no_preproc.sh
bashl mil_subseq10_tmt_no_preproc.sh
bashl rct_subseq10_tmt_no_preproc.sh
