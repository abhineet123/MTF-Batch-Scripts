#!/bin/bash -v
bashl tld_subseq10_tmt_no_preproc.sh
bashl frg_subseq10_tmt_no_preproc.sh
bashl gtrn_subseq10_tmt_no_preproc.sh
