#!/bin/bash -v
bash ./cmt2_subseq10_vot16_jaccard.sh
bash ./cmt3_subseq10_vot16_jaccard.sh
