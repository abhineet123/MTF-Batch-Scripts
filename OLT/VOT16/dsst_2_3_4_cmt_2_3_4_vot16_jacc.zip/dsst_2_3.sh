#!/bin/bash -v
bash ./dsst2_subseq10_vot16_jaccard.sh
bash ./dsst3_subseq10_vot16_jaccard.sh
