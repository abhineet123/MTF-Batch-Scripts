#!/bin/bash -v
bash ./dsst2_subseq10_vot16_jaccard_no_pre_proc.sh
bash ./dsst3_subseq10_vot16_jaccard_no_pre_proc.sh
