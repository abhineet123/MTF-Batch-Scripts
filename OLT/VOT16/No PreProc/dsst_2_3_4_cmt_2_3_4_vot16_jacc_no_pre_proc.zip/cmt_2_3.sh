#!/bin/bash -v
bash ./cmt2_subseq10_vot16_jaccard_no_pre_proc.sh
bash ./cmt3_subseq10_vot16_jaccard_no_pre_proc.sh
