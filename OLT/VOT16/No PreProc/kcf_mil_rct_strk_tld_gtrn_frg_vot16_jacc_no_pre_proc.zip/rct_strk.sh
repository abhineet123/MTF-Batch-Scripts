#!/bin/bash -v
bash ./rct_subseq10_vot16_jaccard_no_pre_proc.sh
bash ./strk_subseq10_vot16_jaccard_no_pre_proc.sh
