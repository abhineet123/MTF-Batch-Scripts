#!/bin/bash -v
bash ./kcf_subseq10_vot16_jaccard_no_pre_proc.sh
bash ./mil_subseq10_vot16_jaccard_no_pre_proc.sh
