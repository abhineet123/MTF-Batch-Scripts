#!/bin/bash -v
bash ./frg_subseq10_vot16_jaccard_no_pre_proc.sh
bash ./tld_subseq10_vot16_jaccard_no_pre_proc.sh
